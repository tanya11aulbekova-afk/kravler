@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Python not found in PATH.
  echo Install Python 3 and enable "Add Python to PATH".
  pause
  exit /b 1
)

python -c "import requests, bs4" >nul 2>nul
if errorlevel 1 (
  echo Installing dependencies...
  python -m pip install --upgrade pip
  python -m pip install requests beautifulsoup4
)

python telegraph_finder_v127.py
