#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegraph Finder v127 (без API-ключей, но расширяет базу через CRAWL)

Добавлено:
- 7) CRAWL from urls_seed.txt: обходит telegra.ph ссылки внутри статей (BFS) -> растит базу без поисковиков
- proxy-check + sticky + лог прокси (как v126)
- локальный поиск по keywords.txt (title + FULL TEXT) + results.csv
"""
from __future__ import annotations

import os, re, json, time, random, csv, math
from typing import Dict, List, Tuple, Optional, Set
from urllib.parse import urlparse, quote_plus, unquote, parse_qs, urljoin

import requests
from bs4 import BeautifulSoup

DB_FILE = "articles_db.json"
SEED_FILE = "urls_seed.txt"
KEYWORDS_FILE = "keywords.txt"
PROXIES_FILE = "proxies.txt"
PROXIES_ALIVE_FILE = "proxies_alive.txt"
PROXIES_DEAD_FILE = "proxies_dead.txt"
RESULTS_CSV = "results.csv"

TIMEOUT = 25
PROXY_TEST_TIMEOUT = 10
MAX_WEB_RESULTS = 80
RETRIES = 3
BASE_DELAY_RANGE = (1.1, 3.0)

STICKY_REQUESTS = 12
CRAWL_MAX_PAGES = 200
CRAWL_MAX_NEW_PER_PAGE = 30

PROXY_TEST_URL = "https://api.ipify.org?format=json"

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/121.0 Safari/537.36",
]

def has_captcha(html: str) -> bool:
    h = (html or "").lower()
    return any(x in h for x in ["captcha", "are you a robot", "unusual traffic", "verify you are human"])

def jitter_sleep(a=BASE_DELAY_RANGE[0], b=BASE_DELAY_RANGE[1]):
    time.sleep(random.uniform(a, b))

def is_telegra(url: str) -> bool:
    try:
        return urlparse(url.strip()).netloc.lower().endswith("telegra.ph")
    except Exception:
        return False

def norm_url(u: str) -> str:
    u = (u or "").strip()
    if "#" in u:
        u = u.split("#",1)[0]
    return u

def load_db() -> Dict[str, dict]:
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_db(db: Dict[str, dict]) -> None:
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def read_proxies() -> List[str]:
    if not os.path.exists(PROXIES_FILE):
        with open(PROXIES_FILE, "w", encoding="utf-8") as f:
            f.write("# HTTP proxies only, one per line\n# ip:port\n# user:pass@ip:port\n")
        return []
    out=[]
    with open(PROXIES_FILE, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith("#"):
                continue
            line=line.strip('"').strip("'")
            if not re.match(r"^https?://", line, flags=re.I):
                line = "http://" + line
            if re.match(r"^https?://", line, flags=re.I):
                out.append(line)
    return out

def rand_headers() -> Dict[str,str]:
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": random.choice(["ru-RU,ru;q=0.9,en;q=0.8", "en-US,en;q=0.9,ru;q=0.7"]),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Connection": "close",
    }

def mask_proxy(p: str) -> str:
    return re.sub(r"(https?://[^:/@]+:)([^@]+)(@)", r"\1***\3", p)

class ProxyPool:
    def __init__(self, proxies: List[str], sticky_requests: int = STICKY_REQUESTS):
        self.all = list(proxies)
        self.alive: List[str] = []
        self.dead: List[str] = []
        self.sticky_requests = max(1, int(sticky_requests))
        self._current: Optional[str] = None
        self._left = 0

    def _rotate(self):
        if not self.alive:
            self._current = None
            self._left = 0
            return
        self._current = random.choice(self.alive)
        self._left = self.sticky_requests

    def get_proxy(self) -> Tuple[Optional[Dict[str,str]], str]:
        if not self._current or self._left <= 0:
            self._rotate()
        if not self._current:
            return None, "DIRECT"
        self._left -= 1
        p = self._current
        return {"http": p, "https": p}, mask_proxy(p)

    def test_one(self, proxy: str) -> Tuple[bool, str]:
        try:
            r = requests.get(PROXY_TEST_URL, headers=rand_headers(),
                             proxies={"http": proxy, "https": proxy},
                             timeout=PROXY_TEST_TIMEOUT)
            r.raise_for_status()
            ip = ""
            try:
                ip = r.json().get("ip", "")
            except Exception:
                ip = (r.text or "").strip()
            return True, ip or "OK"
        except Exception as e:
            return False, str(e)

    def check_all(self):
        self.alive = []
        self.dead = []
        if not self.all:
            return
        print(f"== Checking proxies: {len(self.all)} ==")
        for i, p in enumerate(self.all, 1):
            ok, info = self.test_one(p)
            if ok:
                self.alive.append(p)
                print(f"[{i}/{len(self.all)}] ALIVE  {mask_proxy(p)}  ip={info}")
            else:
                self.dead.append(p)
                print(f"[{i}/{len(self.all)}] DEAD   {mask_proxy(p)}  err={info}")
            time.sleep(random.uniform(0.4, 1.2))
        with open(PROXIES_ALIVE_FILE, "w", encoding="utf-8") as f:
            for p in self.alive: f.write(p+"\n")
        with open(PROXIES_DEAD_FILE, "w", encoding="utf-8") as f:
            for p in self.dead: f.write(p+"\n")
        print(f"Alive: {len(self.alive)} | Dead: {len(self.dead)}")
        print(f"Saved: {os.path.abspath(PROXIES_ALIVE_FILE)}")
        print(f"Saved: {os.path.abspath(PROXIES_DEAD_FILE)}")

def fetch(url: str, pool: ProxyPool) -> str:
    last_err: Optional[Exception] = None
    for attempt in range(1, RETRIES+1):
        proxy_dict, proxy_label = pool.get_proxy()
        try:
            print(f"[HTTP] {proxy_label} -> {url}")
            r = requests.get(url, headers=rand_headers(), proxies=proxy_dict, timeout=TIMEOUT)
            r.raise_for_status()
            txt = r.text
            if has_captcha(txt):
                raise RuntimeError("CAPTCHA/anti-bot page detected")
            return txt
        except Exception as e:
            last_err = e
            print(f"[RETRY {attempt}/{RETRIES}] {proxy_label} error: {e}")
            time.sleep((attempt ** 2) * random.uniform(0.9, 1.8))
    raise last_err  # type: ignore

def parse_article_and_links(url: str, pool: ProxyPool) -> Tuple[str, str, List[str]]:
    html = fetch(url, pool)
    soup = BeautifulSoup(html, "html.parser")
    title_el = soup.find("h1")
    title = title_el.get_text(" ", strip=True) if title_el else ""
    article = soup.find("article") or soup
    parts=[]
    for el in article.find_all(["h1","h2","h3","p","li","blockquote"]):
        t = el.get_text(" ", strip=True)
        if t:
            parts.append(t)
    text = "\n".join(parts).strip()

    found=[]
    for a in soup.select("a[href]"):
        href = a.get("href","").strip()
        if not href:
            continue
        if href.startswith("/"):
            href = urljoin("https://telegra.ph", href)
        href = norm_url(href)
        if is_telegra(href):
            found.append(href)
    seen=set(); out=[]
    for u in found:
        if u in seen: continue
        seen.add(u); out.append(u)
        if len(out) >= CRAWL_MAX_NEW_PER_PAGE:
            break
    return title, text, out

def add_one(url: str, db: Dict[str,dict], pool: ProxyPool) -> bool:
    url = norm_url(url)
    if not url or not is_telegra(url) or url in db:
        return False
    title, text, _ = parse_article_and_links(url, pool)
    db[url] = {"title": title, "text": text}
    print(f"[ADDED] {title[:80]}  ({url})")
    return True

def add_urls(urls: List[str], db: Dict[str,dict], pool: ProxyPool) -> int:
    added=0
    for u in urls:
        try:
            if add_one(u, db, pool):
                added += 1
        except Exception as e:
            print(f"[FAIL] {u}: {e}")
        jitter_sleep()
    return added

# web search (best-effort)
def normalize_to_telegra(href: str) -> Optional[str]:
    if not href:
        return None
    if "telegra.ph/" in href:
        m = re.search(r"(https?://telegra\.ph/[^\s\"'>]+)", href)
        if m:
            return m.group(1).rstrip(").,]")
    try:
        u = urlparse(href)
        host = u.netloc.lower()
        if host.endswith("duckduckgo.com") and u.path.startswith("/l/"):
            qs = parse_qs(u.query)
            if "uddg" in qs and qs["uddg"]:
                return unquote(qs["uddg"][0])
    except Exception:
        pass
    return None

def extract_telegra_links(html: str) -> List[str]:
    soup = BeautifulSoup(html, "html.parser")
    out=[]
    for a in soup.select("a[href]"):
        u = normalize_to_telegra(a.get("href"))
        if u and is_telegra(u):
            out.append(norm_url(u))
    seen=set(); res=[]
    for u in out:
        if u in seen: continue
        seen.add(u); res.append(u)
    return res

def ddg_html_search(q: str, pool: ProxyPool) -> List[str]:
    url = "https://duckduckgo.com/html/?q=" + quote_plus("site:telegra.ph " + q)
    return extract_telegra_links(fetch(url, pool))

def ddg_lite_search(q: str, pool: ProxyPool) -> List[str]:
    url = "https://lite.duckduckgo.com/lite/?q=" + quote_plus("site:telegra.ph " + q)
    return extract_telegra_links(fetch(url, pool))

def bing_search(q: str, pool: ProxyPool) -> List[str]:
    url = "https://www.bing.com/search?q=" + quote_plus("site:telegra.ph " + q)
    return extract_telegra_links(fetch(url, pool))

def mojeek_search(q: str, pool: ProxyPool) -> List[str]:
    url = "https://www.mojeek.com/search?q=" + quote_plus("site:telegra.ph " + q)
    return extract_telegra_links(fetch(url, pool))

def web_search(q: str, pool: ProxyPool, max_results: int = MAX_WEB_RESULTS) -> List[str]:
    urls=[]
    engines=[("DDG_HTML", ddg_html_search), ("DDG_LITE", ddg_lite_search), ("BING", bing_search), ("MOJEEK", mojeek_search)]
    for name, fn in engines:
        try:
            print(f"[SEARCH] {name} ...")
            got = fn(q, pool)
            for u in got:
                if u not in urls:
                    urls.append(u)
                if len(urls) >= max_results:
                    return urls
            jitter_sleep(1.3, 3.6)
        except Exception as e:
            print(f"[SEARCH FAIL] {name}: {e}")
            jitter_sleep(1.0, 2.2)
    return urls

def read_seed_urls() -> List[str]:
    if not os.path.exists(SEED_FILE):
        with open(SEED_FILE, "w", encoding="utf-8") as f:
            f.write("# one telegra.ph url per line\n")
        return []
    with open(SEED_FILE, "r", encoding="utf-8", errors="ignore") as f:
        return [line.strip() for line in f if line.strip() and not line.strip().startswith("#")]

def crawl_from_seeds(db: Dict[str,dict], pool: ProxyPool, seeds: List[str], max_pages: int = CRAWL_MAX_PAGES) -> int:
    q=[]
    seen=set()
    for s in seeds:
        s=norm_url(s)
        if s and is_telegra(s) and s not in seen:
            seen.add(s); q.append(s)
    added=0
    visited=0
    while q and visited < max_pages:
        url=q.pop(0)
        visited += 1
        try:
            title, text, links = parse_article_and_links(url, pool)
            if url not in db:
                db[url]={"title": title, "text": text}
                added += 1
                print(f"[CRAWL ADDED] {title[:80]}  ({url})")
            for lk in links:
                lk=norm_url(lk)
                if lk and is_telegra(lk) and lk not in seen:
                    seen.add(lk); q.append(lk)
        except Exception as e:
            print(f"[CRAWL FAIL] {url}: {e}")
        jitter_sleep()
        if visited % 25 == 0:
            save_db(db)
            print(f"[CRAWL] visited={visited} added={added} queue={len(q)}")
    return added

def read_keywords() -> Tuple[str, List[str]]:
    if not os.path.exists(KEYWORDS_FILE):
        with open(KEYWORDS_FILE, "w", encoding="utf-8") as f:
            f.write("MODE=OR\n# one word/phrase per line\nroblox\naccount\n")
    mode="OR"
    words=[]
    with open(KEYWORDS_FILE, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith("#"):
                continue
            if line.upper().startswith("MODE="):
                m=line.split("=",1)[1].strip().upper()
                if m in ("OR","AND"): mode=m
                continue
            words.append(line)
    seen=set(); out=[]
    for w in words:
        w=w.strip()
        if not w: continue
        k=w.lower()
        if k in seen: continue
        seen.add(k); out.append(w)
    return mode, out

def match_content(content: str, words: List[str], mode: str) -> bool:
    content=content.lower()
    if mode == "AND":
        return all(w.lower() in content for w in words)
    return any(w.lower() in content for w in words)

def search_local(db: Dict[str,dict], mode: str, words: List[str]) -> List[Dict[str,str]]:
    res=[]
    for url,it in db.items():
        content=((it.get("title","")+"\n"+it.get("text",""))).lower()
        if match_content(content, words, mode):
            res.append({"url": url, "title": it.get("title",""), "text": it.get("text","")})
    res.sort(key=lambda x: (x["title"] or "").lower())
    return res

def export_results(rows: List[Dict[str,str]], path: str = RESULTS_CSV) -> str:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w=csv.writer(f)
        w.writerow(["url","title","text"])
        for r in rows:
            w.writerow([r["url"], r["title"], r["text"]])
    return os.path.abspath(path)

def main():
    print("=== Telegraph Finder v127 ===")
    proxies = read_proxies()
    pool = ProxyPool(proxies, sticky_requests=STICKY_REQUESTS)
    if proxies:
        pool.check_all()
        if not pool.alive:
            print("No alive proxies -> DIRECT")
            pool = ProxyPool([], sticky_requests=STICKY_REQUESTS)
    else:
        print("Proxies: none (DIRECT)")

    db = load_db()
    print("DB:", os.path.abspath(DB_FILE))
    print("Articles in DB:", len(db))
    print()
    print("Choose:")
    print(" 1) Add ONE telegra.ph URL to DB")
    print(" 2) Add from urls_seed.txt (list of URLs)")
    print(" 3) WEB search (DDG/Bing/Mojeek) -> add found URLs to DB (best-effort)")
    print(" 4) Local SEARCH by keywords.txt (title + FULL TEXT) + export results.csv")
    print(" 7) CRAWL from urls_seed.txt (expand DB by telegra.ph links inside articles)")
    print(" 0) Exit")
    c=input("> ").strip()

    if c=="1":
        u=input("Paste telegra.ph URL: ").strip()
        added=add_urls([u], db, pool); save_db(db); print("Added:", added)
    elif c=="2":
        urls=read_seed_urls()
        added=add_urls(urls, db, pool); save_db(db); print("Added:", added)
    elif c=="3":
        q=input("Search query (English works better): ").strip()
        urls=web_search(q, pool, max_results=MAX_WEB_RESULTS)
        print("Found URLs:", len(urls))
        added=add_urls(urls, db, pool); save_db(db); print("Added:", added)
    elif c=="7":
        seeds=read_seed_urls()
        if not seeds:
            print("urls_seed.txt empty. Add at least 1 telegra.ph URL.")
        else:
            added=crawl_from_seeds(db, pool, seeds, max_pages=CRAWL_MAX_PAGES)
            save_db(db); print("Crawl added:", added); print("DB size:", len(db))
    elif c=="4":
        mode, words = read_keywords()
        rows=search_local(db, mode, words)
        print(f"MODE={mode} words={len(words)} matches={len(rows)}")
        path=export_results(rows, RESULTS_CSV)
        print("Saved:", path)
    else:
        return
    input("\nPress Enter to exit...")

if __name__=="__main__":
    main()
